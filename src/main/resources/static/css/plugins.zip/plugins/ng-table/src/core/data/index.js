export * from './dataSettings';
export * from './getData';
export * from './interceptor';
export * from './ngTableDefaultGetData';
export * from './results';
//# sourceMappingURL=index.js.map