export interface IDataSettings {
    applyFilter?: boolean;
    applyPaging?: boolean;
    applySort?: boolean;
}
