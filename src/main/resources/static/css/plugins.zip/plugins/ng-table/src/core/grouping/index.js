export * from './getGroup';
export * from './groupingFunc';
export * from './groupSettings';
export * from './ngTableDefaultGetGroups';
//# sourceMappingURL=index.js.map