/// <reference types="angular" />
import * as ng1 from 'angular';
declare const ngTableModule: ng1.IModule;
export { ngTableModule };
export * from './src/core';
export * from './src/browser';
