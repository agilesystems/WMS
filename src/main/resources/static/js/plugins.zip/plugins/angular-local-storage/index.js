require('./dist/angular-local-storage.js');
module.exports = 'LocalStorageModule';
